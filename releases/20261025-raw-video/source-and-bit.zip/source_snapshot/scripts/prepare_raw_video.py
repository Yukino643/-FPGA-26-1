"""把离线视频制作为RV16帧流；不会修改原视频或TF卡。"""
from pathlib import Path
import argparse
import hashlib
import json
import struct
import subprocess
import tempfile

from PIL import Image, ImageDraw

WIDTH, HEIGHT, FPS = 320, 180, 10
FRAME_BYTES = WIDTH * HEIGHT * 2


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--ffmpeg', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--seconds', type=float, default=10)
    args = parser.parse_args()
    if not args.input.is_file() or not args.ffmpeg.is_file() or not 0 < args.seconds <= 60:
        raise ValueError('输入视频、FFmpeg路径或片长无效')
    args.output.mkdir(parents=True, exist_ok=True)
    dest = args.output / 'VIDEO.R16'
    if dest.exists():
        raise FileExistsError('不覆盖既有素材：' + str(dest))
    with tempfile.TemporaryDirectory(prefix='rv16-') as tmp:
        raw = Path(tmp) / 'frames.rgb565'
        proc = subprocess.run([str(args.ffmpeg), '-nostdin', '-hide_banner', '-loglevel', 'error',
            '-i', str(args.input), '-t', str(args.seconds), '-map', '0:v:0', '-an',
            '-vf', 'fps=10,scale=320:180:force_original_aspect_ratio=decrease,'
                   'pad=320:180:(ow-iw)/2:(oh-ih)/2,setsar=1,vflip',
            '-pix_fmt', 'rgb565le', '-f', 'rawvideo', str(raw)], capture_output=True)
        if proc.returncode:
            raise RuntimeError('视频转换失败：' + proc.stderr.decode('utf-8', errors='replace'))
        payload = raw.read_bytes()
    count, rem = divmod(len(payload), FRAME_BYTES)
    if rem or not 1 <= count <= 65535:
        raise ValueError('转换后的帧大小或数量不合法')
    header = struct.pack('<4sHHHHIIII', b'RV16', 1, WIDTH, HEIGHT, FPS,
                         count, FRAME_BYTES, 512, 1).ljust(512, b'\0')
    with dest.open('xb') as dst:
        dst.write(header)
        dst.write(payload)
    data = dest.read_bytes()
    if data[:512] != header or data[512:] != payload or len(data) % 512:
        raise RuntimeError('素材独立回读不一致')
    sheet = Image.new('RGB', (WIDTH * 4, (HEIGHT + 24) * 3), '#101923')
    draw = ImageDraw.Draw(sheet)
    selected = sorted(set(round(i * (count - 1) / 11) for i in range(12)))
    for pos, n in enumerate(selected):
        frame = payload[n * FRAME_BYTES:(n + 1) * FRAME_BYTES]
        pixels = bytearray(WIDTH * HEIGHT * 3)
        # 独立逐像素解565、翻回正向，避免预览掩盖素材行序/字节序错误。
        for y in range(HEIGHT):
            for x in range(WIDTH):
                word = struct.unpack_from('<H', frame, ((HEIGHT - 1 - y) * WIDTH + x) * 2)[0]
                r, g, b = (word >> 11) & 31, (word >> 5) & 63, word & 31
                i = (y * WIDTH + x) * 3
                pixels[i:i + 3] = bytes(((r << 3) | (r >> 2), (g << 2) | (g >> 4), (b << 3) | (b >> 2)))
        ox, oy = (pos % 4) * WIDTH, (pos // 4) * (HEIGHT + 24)
        sheet.paste(Image.frombytes('RGB', (WIDTH, HEIGHT), bytes(pixels)), (ox, oy))
        draw.text((ox + 6, oy + HEIGHT + 4), f'FRAME {n:03d} / {n / FPS:.1f}s', fill='white')
    sheet.save(args.output / 'contact_sheet.png')
    # 首、次和尾帧扇区夹具供RTL直接消费，十六进制字节一行一个。
    for name, offset, size in [('header', 0, 512), ('frame0', 512, FRAME_BYTES),
                               ('frame1', 512 + min(1, count - 1) * FRAME_BYTES, FRAME_BYTES),
                               ('last', 512 + (count - 1) * FRAME_BYTES, FRAME_BYTES)]:
        (args.output / (name + '.hex')).write_text(
            ''.join(f'{v:02x}\n' for v in data[offset:offset + size]), encoding='ascii', newline='\n')
    meta = {'input': str(args.input.resolve()), 'input_sha256': hashlib.sha256(args.input.read_bytes()).hexdigest(),
            'format': 'RV16 v1 RGB565 little endian bottom-up, 512-byte header',
            'width': WIDTH, 'height': HEIGHT, 'fps': FPS, 'frames': count,
            'duration_seconds': count / FPS, 'frame_bytes': FRAME_BYTES,
            'frame_sectors': FRAME_BYTES // 512, 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest(), 'audio': False}
    (args.output / 'metadata.json').write_text(json.dumps(meta, ensure_ascii=False, indent=2) + '\n',
                                              encoding='utf-8', newline='\n')
    print(json.dumps(meta, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
