"""使用同一完整测试台做原生C++编译仿真，避免解释执行的墙钟超时。"""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

import verify_raw_video as shared

ROOT=shared.ROOT
OUT=shared.OUT
VROOT=ROOT/'build/raw_video/tools/verilator_py/verilator'
OBJ=OUT/'compiled'
CXX=Path('D:/minGW64/mingw64/bin/g++.exe')

def main():
    shared.prepare()
    OBJ.mkdir(exist_ok=True)
    files=['sim/tb_raw_video_pipeline.v','sim/raw_video_card_model.v','rtl/sd/raw_video_player.v',
           'rtl/sd/fat32_bmp_index.v','rtl/sd/fat32_file_sector_mapper.v','rtl/video/video_frame_commit.v',
           'rtl/sd/src_packer.v','rtl/sd/source_scaler_gate.v','rtl/sd/frame_read_write.v','rtl/sd/frame_fifo_write.v',
           'rtl/pll/afifo_16_32_256.v','rtl/video/resize_frame_720.v','rtl/video/display_stream_720.v',
           'rtl/video/disp_mixer_565.v','rtl/mem/disp_read_engine.v','rtl/mem/afifo_simple.v','rtl/mem/mem_mpu.v',
           'rtl/video/video_timing_gen.v','sim/sdram_beh.v']
    inputs={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
            for folder in ('rtl','sim') for p in (ROOT/folder).rglob('*') if p.is_file() and p.suffix in ('.v','.vh','.hex')}
    env=os.environ.copy()
    env['VERILATOR_ROOT']=VROOT.as_posix()
    env['PATH']=str(CXX.parent)+os.pathsep+env['PATH']
    commands=[('generate',[str(VROOT/'bin/verilator_bin.exe'),'--cc','--main','--timing','--assert',
        '-DSIMULATION','-Wno-fatal','--top-module','tb_raw_video_pipeline','--Mdir',OBJ.as_posix(),
        '-I'+OUT.as_posix(),*[str(ROOT/name) for name in files]])]
    started=time.monotonic()
    for name,command in commands:
        with (OUT/('pipeline_compiled_'+name+'.log')).open('wb') as log:
            subprocess.run(command,cwd=OUT,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
    print('COMPILED_PIPELINE generated',flush=True)
    # 直接调用原生编译器，避免Make/Perl或另一种shell引入路径/编码差异。
    cpp=[str(p) for p in sorted(OBJ.glob('*.cpp'))]
    include=VROOT/'include'
    exe=OBJ/'pipeline.exe'
    command=[str(CXX),'-std=c++20','-O2','-pthread','-DVL_TIME_CONTEXT','-I'+str(include),'-I'+str(include/'vltstd'),'-I'+str(OBJ),
             *cpp,*[str(include/n) for n in ('verilated.cpp','verilated_timing.cpp','verilated_threads.cpp')],'-o',str(exe)]
    with (OUT/'pipeline_compiled_compile.log').open('wb') as log:
        subprocess.run(command,cwd=OUT,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
    print('COMPILED_PIPELINE C++ compiled',flush=True)
    with (OUT/'pipeline_sim.log').open('wb') as log:
        subprocess.run([str(exe)],cwd=OUT,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
    text=(OUT/'pipeline_sim.log').read_text(encoding='utf-8')
    if 'PASS raw_video_pipeline' not in text or 'FAIL' in text or 'ERROR' in text:
        raise RuntimeError('完整视频测试未通过：'+text[-2000:])
    for name,digest in inputs.items():
        if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=digest:
            raise RuntimeError('仿真期间输入变化：'+name)
    result={'results':[{'name':'pipeline','pass':True,'seconds':round(time.monotonic()-started,1),
                        'engine':'native Verilator compiled C++20; unchanged full 720p testbench'}],
            'inputs_sha256':inputs}
    (OUT/'pipeline_results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(text,flush=True)
    print('COMPILED_PIPELINE PASS',flush=True)

if __name__=='__main__':
    main()
